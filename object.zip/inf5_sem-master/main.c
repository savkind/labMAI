#include <stdio.h>

int main(void) {
	int i =0;
	while(i<1000){
		printf ("%d\n",i);
		i++;
	}
	return 0;
}